#include <iostream>
using namespace std;

struct Student
{
    int marks1, marks2, marks3;
    float avg;
};

int main()
{
    int n;
    cout << "Enter number of students: ";
    cin >> n;

    Student s[n];

    for(int i = 0; i < n; i++)
    {
        cout << "\nEnter marks of student " << i + 1 << endl;
        cin >> s[i].marks1 >> s[i].marks2 >> s[i].marks3;

        s[i].avg = (s[i].marks1 + s[i].marks2 + s[i].marks3) / 3.0;
    }

    cout << "\nAverage Marks of Students:\n";
    for(int i = 0; i < n; i++)
    {
        cout << "Student " << i + 1 << " Average = " << s[i].avg << endl;
    }

    return 0;
}