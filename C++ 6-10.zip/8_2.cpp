#include<iostream>
main()
{
	int i,j,k,rows;
	std::cin>>rows;
	for(i=1;i<=rows;i++)
	{
		for(j=1;j<=rows-i;j++)
	 {
		std::cout<<" ";
	 }
	 for(k=1;k<=i*2-1;k++)
	 {
	 	std::cout<<"*";
	 }
	 std::cout<<"\n";
	 }
	 for(i=rows-1;i>0;i--)
	 {
		for(j=1;j<=rows-i;j++)
	 {
		std::cout<<" ";
	 }
	 for(k=1;k<=i*2-1;k++)
	 {
	 	std::cout<<"*";
	 }
	 std::cout<<"\n";
	 }
	 return 0;
}
