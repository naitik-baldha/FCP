#include<iostream>
#include<string>
using namespace std;

class student
{
	public:
		string name;
		int roll_no;
};

int main()
{
	student s1;
	
	s1.roll_no=2;
	s1.name="ajay";
	
	cout<<"roll number:"<<s1.roll_no<<endl;
	cout<<"name:"<<s1.name<<endl;
	return 0;
}