//Write a program to Swapping two variables value using call by value, call by reference and call by address.
#include<iostream>
using namespace std;

void swapValue(int a, int b) 
{
    int temp = a;
    a = b;
    b = temp;
}

void swapReference(int &a, int &b) 
{
    int temp = a;
    a = b;
    b = temp;
}

void swapAddress(int *a, int *b) 
{
    int temp = *a;
    *a = *b;
    *b = temp;
}

int main() 
{
    int x = 10, y = 20;
    swapValue(x, y);
    cout << "Call by Value: x = " << x << " y = " << y;
    
    swapReference(x, y);
    cout << "\nCall by Reference: x = " << x << " y = " << y;
    
    swapAddress(&x, &y);
    cout << "\nCall by Address: x = " << x << " y = " << y;
    return 0;
}