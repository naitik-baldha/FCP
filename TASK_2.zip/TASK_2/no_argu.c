#include <stdio.h>
#include<conio.h>

void sum1();

int main()  
{
    printf("hello\n");
    sum1();
    
}

void sum1()
{
    int n1 = 5, n2 = 5, sum;
    sum = n1 + n2;
    printf("%d\n", sum);
}
