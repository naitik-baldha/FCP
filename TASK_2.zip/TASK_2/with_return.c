#include <stdio.h>
#include<conio.h>
int sum1(int, int);  

int main()  
{
    int n1 = 1, n2 = 2;
    int result;

    result = sum1(n1, n2);
    printf("%d\n", result);

    getch();
}

int sum1(int n1, int n2)
{
    int sum = n1 + n2;
    return sum;
}
