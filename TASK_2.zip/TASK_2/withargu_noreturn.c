#include <stdio.h>

void sum1(int, int);

int main()
{
    int n1 = 5, n2 = 5;
    sum1(n1, n2);
    getch();
}

void sum1(int n1, int n2)
{
    int sum = n1 + n2;
    printf("%d\n", sum);
}
