#include<stdio.h>
#include<conio.h>
struct example 
{
	int number;
	float marks;
	char name[20];
};
main()
{
	struct example n[3];
	int i;
	for(i=0;i<3;i++)
	{
		scanf("%d %s %f",&n[i].number,n[i].name,&n[i].marks);
	}
	for(i=0;i<3;i++)
	{
		printf("%d %s %f",n[i].number,n[i].name,n[i].marks);
	}
	getch();
}

