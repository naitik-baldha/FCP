#include<stdio.h>
#include<conio.h>
main()
{
     char ch;
     printf("enter any character=");
     scanf("%c",&ch);
     if(ch>='A'&&ch<= 'Z')
     {
     printf("%c this is alphabetic letter"); 
     }
     else
     {
     printf("%c this is not alphabetic letter");
     }
     getch();
}
