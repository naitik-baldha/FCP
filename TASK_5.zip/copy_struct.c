#include<stdio.h>
#include<conio.h>
struct names
{
	int id;
	char grade;
};

int main()
{
	struct names s1={1, 'a'};
	struct names s1c=s1;
	
	printf("%d\n",s1c.id);
	printf("%c\n",s1c.grade);
	getch();
}