#include<stdio.h>
#include<conio.h>
main()
{
	int a;
	while(a<=10)
	{
		printf("hello\n",a);
		a++;
	}
	getch();
}