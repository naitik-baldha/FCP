#include<stdio.h>
#include<conio.h>
main() 
{
    int i,j;
    for (i=1;i<=5;i++) 
	{
        for (j=1;j<=i;j++)
		{
            printf("%c",64+j); 
        }
        printf("\n"); 
    }
    getch();
}
