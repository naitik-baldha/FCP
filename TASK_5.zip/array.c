#include<stdio.h>
#include<conio.h>
main()
{
    int rollnumber[5];
    float marks[5];
	printf("Enter the roll numbers and marks:\n");
	for (int i = 0; i < 5; i++)
	{
		printf("Student %d:\n",i + 1);
        printf("rollnumber:");
        scanf("%d", &rollnumber[i]);
        printf("Marks: ");
        scanf("%f", &marks[i]);
	}
	printf("\nStored Information of Students:\n");
    for (int i = 0; i < 5; i++) 
	{
        printf("Student %d - Roll Number: %d, Marks: %.2f\n", i + 1, rollnumber[i], marks[i]);
    }   
	getch(); 
}