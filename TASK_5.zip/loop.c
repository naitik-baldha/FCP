#include<stdio.h>
#include<conio.h>
main()
{
	int i;
	for(i=1;i<=8;i++)
	{
		printf("hello\n");
	}
	getch();
}