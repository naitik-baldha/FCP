#include<stdio.h>
#include<conio.h>
#include<string.h>
main()
{
	char s1[15];
	printf("enter string");
	gets(s1);//gets=get string,string input//
	printf("string= %s",s1);
	printf("\nstring in lower case=%s",strlwr(s1));//string in lower case//
	printf("\nstring in lower case=%s",strupr(s1));//string in upper case//
	printf("\nlength=%d",strlen(s1));
	getch();
}