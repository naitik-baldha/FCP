#include <stdio.h>
#include <conio.h>
struct personal {
    char name[50];
    char joining_date[15];
    float salary;
};

int main() {
    struct personal p[5];
    int i;

    for (i = 0; i < 5; i++) {
        printf("Enter details of person %d:\n", i + 1);
        printf("Name: ");
        scanf("%s", p[i].name);

        printf("Joining Date (dd/mm/yyyy): ");
        scanf("%s", p[i].joining_date);

        printf("Salary: ");
        scanf("%f", &p[i].salary);
        printf("\n");
    }

    printf("\n----- Employee Details -----\n");
    for (i = 0; i < 5; i++) {
        printf("Person %d:\n", i + 1);
        printf("Name: %s\n", p[i].name);
        printf("Joining Date: %s\n", p[i].joining_date);
        printf("Salary: %.2f\n\n", p[i].salary);
    }

    getch();
}

