#include <stdio.h>
#include <conio.h>
main() 
{
    int a, b,sum;
    printf("Enter :");
    scanf("%d %d", &a,&b);
    sum=a+b;
    printf("Sum: %d",sum);
    getch();
}