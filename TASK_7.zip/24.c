#include <stdio.h>
#include <stdlib.h> 
int main() 
{
    FILE *fptr;
    char content[100];
    char ch;

  
    fptr = fopen("user_content.txt", "w"); 

    if (fptr == NULL) {
        printf("Error opening file for writing!\n");
        exit(1); 
    }

    printf("Enter content to store in the file (max 99 characters, press Enter to finish):\n");
    fgets(content, sizeof(content), stdin); 

    fprintf(fptr, "%s", content); 

    fclose(fptr); 
    printf("\nContent successfully written to user_content.txt\n");

    
    fptr = fopen("user_content.txt", "r");

    if (fptr == NULL) {
        printf("Error opening file for reading!\n");
        exit(1); 
    }

    printf("\nContent of user_content.txt:\n");
    
    while ((ch = fgetc(fptr)) != EOF) {
        printf("%c", ch);
    }

    fclose(fptr); 

    getch(); 
}
