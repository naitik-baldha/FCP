#include <stdio.h>
#include <stdlib.h> 

int main() {
    FILE *sourceFile1, *sourceFile2, *destFile;
    char ch;

    sourceFile1 = fopen("file1.txt", "r");
    if (sourceFile1 == NULL) {
        printf("Error: Could not open file1.txt\n");
        exit(EXIT_FAILURE);
    }

    sourceFile2 = fopen("file2.txt", "r");
    if (sourceFile2 == NULL) {
        printf("Error: Could not open file2.txt\n");
        fclose(sourceFile1); 
        exit(EXIT_FAILURE);
    }

    destFile = fopen("merged.txt", "w");
    if (destFile == NULL) {
        printf("Error: Could not create/open merged.txt\n");
        fclose(sourceFile1);
        fclose(sourceFile2);
        exit(EXIT_FAILURE);
    }

    while ((ch = fgetc(sourceFile1)) != EOF) {
        fputc(ch, destFile);
    }

    while ((ch = fgetc(sourceFile2)) != EOF) {
        fputc(ch, destFile);
    }

    printf("Files merged successfully into merged.txt\n");

    fclose(sourceFile1);
    fclose(sourceFile2);
    fclose(destFile);

    getch();
}
