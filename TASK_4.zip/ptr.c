#include<stdio.h>
#include<conio.h>
main()
{
	int i;
	int v1=10;
	int v2=20;
	int v3=30;
	
	int*ptr_arr[3]={&v1,&v2,&v3};
	
	for(i=0;i<3;i++)
	{
		printf("value of %d:%d\t address%p\n",i+1,*ptr_arr[i],ptr_arr[i]);
	}
	getch();
}