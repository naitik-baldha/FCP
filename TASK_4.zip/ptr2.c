#include<stdio.h>
#include<conio.h>
void display();
void main()
{
	printf("hello\n");
	display();
	getch();
}
void display()
{
	int i;
	for(i=1;i<5;i++)
	{
		if(i==3)
		break;
		display();
	}
}