#include<stdio.h>
#include<conio.h>
main()
{
	FILE*fptr;
	fptr = fopen("abc2.txt", "a");
	fprintf(fptr,"good");
	fclose(fptr);
}