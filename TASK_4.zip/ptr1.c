#include<stdio.h>
#include<conio.h>
*pointer;
int*fun()
{
	int n1=10;
	return(&n1);
}
main()
{
	int*p;
	p=fun();
	printf("%p\n",p);
	printf("%p\n",*p);
	getch();
}