#include<stdio.h>
#include<conio.h>
main()
{
	FILE*fptr;
	fptr = fopen("abc.txt", "w");
	fprintf(fptr, "how are you!");
	fprintf(fptr, "\nbuddy");
	fclose(fptr);
}
