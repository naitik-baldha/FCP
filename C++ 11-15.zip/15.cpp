#include <iostream>
#include <string>
using namespace std;

class employee
{
public:
    int empno;
    string empname;
    float basic;
    float da;
    float it;
    float netsalary;

    void readData()
    {
        cout << "Enter employee number: ";
        cin >> empno;

        cout << "Enter employee name: ";
        cin >> empname;

        cout << "Enter basic salary: ";
        cin >> basic;
    }

    void calculateSalary()
    {
        da = 0.52 * basic;                  // DA = 52% of Basic
        float grossSalary = basic + da;     // Gross Salary
        it = 0.30 * grossSalary;            // IT = 30% of Gross
        netsalary = grossSalary - it;       // Net Salary
    }

    void displayData()
    {
        cout << "\nEmployee Number: " << empno << endl;
        cout << "Employee Name: " << empname << endl;
        cout << "Basic Salary: " << basic << endl;
        cout << "DA: " << da << endl;
        cout << "Income Tax: " << it << endl;
        cout << "Net Salary: " << netsalary << endl;
    }
};

int main()
{
    int n;

    cout << "Enter number of employees: ";
    cin >> n;

    employee e[n];

    for (int i = 0; i < n; i++)
    {
        cout << "\nEnter details of employee " << i + 1 << endl;
        e[i].readData();
        e[i].calculateSalary();
    }

    cout << "\nEmployee Salary Details" << endl;

    for (int i = 0; i < n; i++)
    {
        e[i].displayData();
    }

    return 0;
}