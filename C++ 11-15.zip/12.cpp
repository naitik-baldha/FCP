#include<iostream>
using namespace std;

class student
{
	public:
		int rollno;
		int age;
		float marks;
};

int main()
{
	student s1;
	s1.rollno=1;
	s1.age=20;
	s1.marks=85.5;
	cout<<"student record:"<<endl;
	cout<<"roll number:"<<s1.rollno<<endl;
	cout<<"age:"<<s1.age<<endl;
	cout<<"marks:"<<s1.marks<<endl;
	return 0;
}