#include <iostream>
using namespace std;

// Class Declaration
class student
{
private:
    int roll_no;

public:
    void setData(int r);
    void display();
};

// Class Definition
void student::setData(int r)
{
    roll_no = r;
}

void student::display()
{
    cout << "Roll number: " << roll_no << endl;
}

int main()
{
    student s1;

    s1.setData(10);
    s1.display();

    return 0;
}