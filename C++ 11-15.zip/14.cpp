#include <iostream>
#include <string>
using namespace std;

class student
{
public:
    string name;
    int rollNo;
    char grade;

    void readData()
    {
        cout << "Enter name: ";
        cin >> name;

        cout << "Enter roll no: ";
        cin >> rollNo;

        cout << "Enter grade: ";
        cin >> grade;
    }

    void displayData()
    {
        cout << "\nName: " << name << endl;
        cout << "Roll No: " << rollNo << endl;
        cout << "Grade: " << grade << endl;
    }
};

int main()
{
    student s[3];

    for (int i = 0; i < 3; i++)
    {
        cout << "\nEnter details of student " << i + 1 << endl;
        s[i].readData();
    }

    cout << "\nStudent Details" << endl;

    for (int i = 0; i < 3; i++)
    {
        s[i].displayData();
    }

    return 0;
}