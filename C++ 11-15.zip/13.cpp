#include<iostream>
#include<string>
using namespace std;

class student
{
	private:
		int eno;
		string name;
		string email;
		string phone;
		int sem;
		public:
			static string college;
			
			void seteno(int e)
			{
				eno=e;
			}
			void setname(string n)
			{
				name=n;
			}
			void setemail(string e)
			{
				email=e;
			}
			void setphone(string p)
			{
				phone=p;
			}
			void setsem(int s)
			{
				sem=s;
			}
			
			void display()
			{
				cout<<"enrollment number:"<<eno<<endl;
				cout<<"name:"<<name<<endl;
				cout<<"email:"<<email<<endl;
				cout<<"phone:"<<phone<<endl;
				cout<<"semester:"<<sem<<endl;
				cout<<"college:"<<college<<endl;
			}
};
string student::college="ssasit";
int main()
{
	student s1;
	s1.seteno(101);
	s1.setname("ajay");
	s1.setemail("ajay@gmail.com");
	s1.setphone("8151623254");
	s1.setsem(5);
	s1.display();
	return 0;
}