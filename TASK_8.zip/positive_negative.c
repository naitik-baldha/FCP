 #include<stdio.h>
 #include<conio.h>
 main()
{
	int n;
	printf("enter the value");
	scanf("%d", &n);
	if(n>0)
	{
		printf("%d is positive",n);
	}
	else if(n<0)
	{
	    printf("%d is negative\n",n);
	}
	else
	{
		printf("%d is zero",n);
	}
	getch();
}
