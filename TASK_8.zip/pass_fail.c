 #include<stdio.h>
 #include<conio.h>
 main()
{
	int marks;
	printf("enter your marks");
	scanf("%d", &marks);
	if(marks>33)
	{
		printf("student is pass:%d\n",marks);
	}
	else
	{
		printf("student is fail:%d",marks);
	}
	getch();
}
