#include<stdio.h>
#include<conio.h>
struct example 
{
	int number;
	float marks;
	char name;
};
main()
{
	struct example n1;
    struct example n2;	 
	n1.name="n";
	n1.number="7";
	n1.marks=7.4;
	n2.name="n";
	n2.number="7";
	n2.marks=7.4;
	
	
	
	printf("n1 name:%c\n",n1.name);
	printf("n1 name:%c\n",n2.name);
	printf("n1 number:%d\n",n1.number);
	printf("n1 number:%d\n",n2.number);
	printf("n1 marks:%f\n",n1.marks);
	printf("n1 marks:%f\n",n2.marks);

	getch();
}

