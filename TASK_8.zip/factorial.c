#include <stdio.h>
#include <conio.h>
int main() 
{
    int i,num,fact=1;
    printf("Enter no:");
    scanf("%d", &num);
    if (num<0)
	{
        printf("Factorial of negative numbers not allowed\n");
    } 
	else 
	{
        for (int i=1;i<=num;i++) 
		{
            fact=fact*i; 
        }
            printf("Factorial of %d=%d\n",num,fact);
        
    }
	getch();
}