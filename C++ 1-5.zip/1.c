#include<iostream>
main()
{
	printf("hello world");
	getch();
}