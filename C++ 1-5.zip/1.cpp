#include<iostream>
main()
{
	std::cout<<"hello world";
	return 0;
}