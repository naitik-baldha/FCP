#include <iostream>
using namespace std;

int main() 
{
    int n;

    cout << "Enter the number of elements: ";
    cin >> n;

    int numbers[n];

    cout << "Enter " << n << " integers:\n";
    for (int i = 0; i < n; i++) 
    {
        cin >> numbers[i];
    }

    int largest = numbers[0];
    int smallest = numbers[0];

    for (int i = 1; i < n; i++) 
    {
        if (numbers[i] > largest) 
        {
            largest = numbers[i];
        }
        if (numbers[i] < smallest) 
        {
            smallest = numbers[i];
        }
    }

    cout << "\nThe array is: ";
    for (int i = 0; i < n; i++) 
    {
        cout << numbers[i] << " ";
    }
    cout << endl;

    cout << "Largest number in the array: " << largest << endl;
    cout << "Smallest number in the array: " << smallest << endl;

    return 0;
}
