// write a c++ program to display matrix multiplication table using nested for loop

# include <iostream>
using namespace std;
int main()
{
	int rows,cols,i,j;
	cout << "enter no of rows: \n";
	cin >> rows;
	cout << "enter no of cols: \n";
	cin >> cols;
	for(i=1;i<=rows;i++)
	{
		for(j=1;j<=cols;j++)
		{
			cout << i * j << "\t";
		}
		cout << endl;
	}
	return 0;
}