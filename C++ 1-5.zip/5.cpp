
#include <iostream>
using namespace std;

int sum(int a, int b, int c = 0, int d = 0) 
{
    return a + b + c + d;
}

int main() 
{
    cout << "Sum of 2 numbers: " << sum(10, 20);          
    cout << "\nSum of 3 numbers: " << sum(10, 20, 30);  
    cout << "\nSum of 4 numbers: " << sum(10, 20, 30, 40);  

    return 0;
}