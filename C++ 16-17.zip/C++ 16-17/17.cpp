#include <iostream>
using namespace std;

class CountObj {
    static int count;   // static variable to count objects

public:
    CountObj() {
        count++;        // increment when object is created
    }

    ~CountObj() {
        count--;        // decrement when object is destroyed
        cout << "Object deleted. Remaining objects: " << count << endl;
    }

    static int getCount() {
        return count;   // return current count
    }
};

// initialize static member
int CountObj::count = 0;

int main() {
    CountObj *o1 = new CountObj();
    CountObj *o2 = new CountObj();

    cout << "Total objects created: " << CountObj::getCount() << endl;

    delete o1;
    delete o2;

    return 0;
}
