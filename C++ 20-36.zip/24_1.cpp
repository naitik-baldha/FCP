#include<iostream>
int add(int a,int b)
{
	return a+b;
}
float add(float a,float b)
{
	return a+b;
}
int add(int a,int b,int c)
{
	return a+b+c;
}
int main()
{
	std::cout<<add(10,20);
	std::cout<<add(2.5f,3.5f);
	std::cout<<add(1,2,3);
}