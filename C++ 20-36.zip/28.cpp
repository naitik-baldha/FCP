#include <iostream>
using namespace std;

class Student {
public:
    int roll;
    void getRoll(int r) {
        roll = r;
    }
};

class Test : virtual public Student {
public:
    int marks1;
    void getMarks(int m) {
        marks1 = m;
    }
};

class Sports : virtual public Student {
public:
    int marks2;
    void getScore(int s) {
        marks2 = s;
    }
};

class Result : public Test, public Sports {
public:
    void display() {
        cout << "Roll No: " << roll << endl;
        cout << "Test Marks: " << marks1 << endl;
        cout << "Sports Marks: " << marks2 << endl;
        cout << "Total: " << marks1 + marks2 << endl;
    }
};

int main() {
    Result r;
    r.getRoll(101);
    r.getMarks(80);
    r.getScore(20);
    r.display();
    return 0;
}
