#include <iostream>
using namespace std;

class Demo {
    int x;

public:
    Demo& set(int x) {
        this->x = x;
        return *this;
    }

    void show() {
        cout << "Value of x: " << x << endl;
    }
};

int main() {
    Demo d;
    d.set(10).show();
    return 0;
}
