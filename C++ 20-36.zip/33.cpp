#include <iostream>
using namespace std;

class Sample {
private:
    int a;

public:
    Sample(int x) {
        a = x;
    }

    friend void show(Sample);      // Friend Function
    friend class Demo;             // Friend Class
};

void show(Sample s) {
    cout << "Friend Function Access: " << s.a << endl;
}

class Demo {
public:
    void display(Sample s) {
        cout << "Friend Class Access: " << s.a << endl;
    }
};

int main() {
    Sample obj(100);

    show(obj);

    Demo d;
    d.display(obj);

    return 0;
}
