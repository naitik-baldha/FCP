#include <iostream>
using namespace std;

class Demo {
    int a, b;

public:
    // Default constructor
    Demo() {
        a = 0;
        b = 0;
    }

    // Parameterized constructor (1 parameter)
    Demo(int x) {
        a = x;
        b = 0;
    }

    // Parameterized constructor (2 parameters)
    Demo(int x, int y) {
        a = x;
        b = y;
    }

    void display() {
        cout << "a = " << a << " b = " << b << endl;
    }
};

int main() {
    Demo d1;        // Default
    Demo d2(5);     // One argument
    Demo d3(5, 10); // Two arguments

    d1.display();
    d2.display();
    d3.display();

    return 0;
}
