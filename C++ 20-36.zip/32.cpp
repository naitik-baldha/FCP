#include <iostream>
#include <fstream>
using namespace std;

int main() {
    ofstream outFile("data.txt");
    outFile << "Hello Naitik\n";
    outFile << "Welcome to C++ File Handling";
    outFile.close();

    ifstream inFile("data.txt");

    inFile.seekg(0, ios::end);
    int pos = inFile.tellg();

    char ch;

    for(int i = pos - 1; i >= 0; i--) {
        inFile.seekg(i);
        inFile.get(ch);
        cout << ch;
    }

    inFile.close();

    return 0;
}
