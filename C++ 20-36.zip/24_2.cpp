#include <iostream>
class complex
{
    int real, imag;
public:
    complex(int r = 0, int i = 0)
    {
        real = r;
        imag = i;
    }
    complex operator+(complex c)
    {
        return complex(real + c.real, imag + c.imag);
    }
     void display()
    {
        cout << real << " + " << imag << "i" << endl;
    }
};

int main()
{
    complex c1(2, 3), c2(4, 5);
    complex c3 = c1 + c2;
    c3.display();
    return 0;
}
