#include <iostream>
using namespace std;

template <class T>
class Box {
    T data;

public:
    Box(T d) {
        data = d;
    }

    void show() {
        cout << "Data: " << data << endl;
    }
};

int main() {
    Box<int> obj1(100);
    Box<string> obj2("Naitik");

    obj1.show();
    obj2.show();

    return 0;
}
