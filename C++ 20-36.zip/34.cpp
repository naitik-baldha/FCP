#include <iostream>
#include <fstream>
using namespace std;

class Inventory {
    int id;
    char name[20];
public:
    void readdata() {
        cout << "Enter ID and name = ";
        cin >> id >> name;
    }
    void displaydata() {
        cout << "ID = " << id << "  name = " << name << endl;
    }
};

int main() {
    Inventory obj;
    cout << "Enter details\n";

    fstream file;
    file.open("stock.txt", ios::in | ios::out | ios::binary | ios::app);

    obj.readdata();

    file.write((char*)&obj, sizeof(obj));

    file.close();

    file.open("stock.txt", ios::in | ios::binary);

    while (file.read((char*)&obj, sizeof(obj))) {
        obj.displaydata();
    }

    file.close();
    return 0;
}
