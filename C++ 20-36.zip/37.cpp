#include <iostream>
using namespace std;

template <typename T>
void swapValues(T &a, T &b) {
    T temp = a;
    a = b;
    b = temp;
}

int main() {
    int x = 10, y = 20;
    swapValues(x, y);
    cout << "Swapped Ints: " << x << " " << y << endl;

    float a = 5.5, b = 9.5;
    swapValues(a, b);
    cout << "Swapped Floats: " << a << " " << b << endl;

    return 0;
}
