#include <iostream>
using namespace std;

class Student {
    int roll;
    static int count;   // Static data member

public:
    Student() {
        count++;        // Increase count whenever object is created
    }

    static void showCount() {   // Static member function
        cout << "Total Objects Created: " << count << endl;
    }
};

// Definition of static data member
int Student::count = 0;

int main() {
    Student s1;
    Student s2;
    Student s3;

    Student::showCount();   // Calling static function

    return 0;
}
