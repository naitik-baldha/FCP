#include <iostream>
#include <string>

using namespace std;

int main() 
{
    string input;

    cout << "Enter text (type 'exit' to End):" << endl;

    while (true) 
	{
        getline(cin, input); 
        if (input == "exit") 
		{
            break;
        }

        cout << "You input: " << input << endl; 
    }

    return 0;
}