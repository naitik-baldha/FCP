#include <iostream>
using namespace std;

int x = 100;

class Base {
public:
    static int count;
    static void showCount() {
        cout << "Static Count: " << count << endl;
    }

    void display();
    void show() {
        cout << "Base class function" << endl;
    }
};

int Base::count = 10;

void Base::display() {
    cout << "Member function defined outside class" << endl;
}

class Derived : public Base {
public:
    void show() {
        cout << "Derived class function" << endl;
        Base::show();
    }
};

int main() {
    int x = 50;

    cout << "Local x: " << x << endl;
    cout << "Global x: " << ::x << endl;

    Base obj;
    obj.display();

    Base::showCount();

    Derived d;
    d.show();

    return 0;
}
