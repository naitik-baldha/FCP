#include<stdio.h>
#include<conio.h>
main()
{
	int a;
	scanf("%d",&a);
	if(a>10)
	{
		if(a<50)
	    {
		    printf("ok");
	    }
	    else
		{
			printf("not ok");
		}
	}
	else
	{
		printf("error");
	}
	getch();
}