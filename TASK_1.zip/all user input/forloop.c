#include<stdio.h>
#include<conio.h>
main()
{
	int i,n;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("hello");
		printf("\n");
	}
	getch();
}