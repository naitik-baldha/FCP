#include<stdio.h>
#include<conio.h>
main()
{
	int i,n;
	scanf("%d",&n);
	do
	{
		printf("hello");
		i++;
		printf("\n");
	}
	while(i<n);
	getch();
}