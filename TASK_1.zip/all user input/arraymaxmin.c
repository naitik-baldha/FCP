#include <stdio.h>
#include<conio.h>
int main() 
{
    int i, a1[2],max,min;
    for (i = 0; i < 2; i++) 
    {
        printf("Enter %d: ", i + 1);
        scanf("%d", &a1[i]);
    }
    max = a1[0];
    for (i = 1; i < 2; i++) 
    {
        if (a1[i] > max) 
        {
            max = a1[i];
        }
    }
    max = a1[0];
    for (i = 1; i < 2; i++) 
    {
        if (a1[i] < min) 
        {
            min = a1[i];
        }
    }
    printf("Maximum: %d\n", max);
    printf("minimum: %d\n", min);
    getch();
}