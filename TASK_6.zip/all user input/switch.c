#include<stdio.h>
#include<conio.h>
main()
{
	int day	;
	scanf("%d",&day);
	if(day<=7)
	{
	switch(day)
	{
		case 1:
		printf("monday");
		break;
		case 2:
		printf("Tuesday");
		break;
		case 3:
		printf("wednesday");
		break;
		case 4:
		printf("Thursday");
		break;
		case 5:
		printf("friday");
		break;
		default:
		printf("holiday");
		break;	
	}
	}
	else
	{
	    printf("error");
	}
	getch();
}
