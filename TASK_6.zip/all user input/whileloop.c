#include<stdio.h>
#include<conio.h>
main()
{
	int i,n;
	scanf("%d",&n);
	while(i<n)
	{
		printf("hello");
		i++;
		printf("\n");
	}
	getch();
}