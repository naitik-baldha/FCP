#include <stdio.h>
#include<conio.h>
int main() 
{
    int i, a1[2],even,odd;
    for (i = 0; i < 2; i++) 
    {
        printf("Enter %d: ", i + 1);
        scanf("%d", &a1[i]);
    }
    even = a1[0];
    for (i = 1; i < 2; i++) 
    {
        if (even %2!=0) 
        {
            even = a1[i];
        }
    }
    odd = a1[0];
    for (i = 1; i < 2; i++) 
    {
        if (odd %2==0) 
        {
            odd = a1[i];
        }
    }
    printf("even: %d\n", even);
    printf("odd: %d\n", odd);
    getch();
}