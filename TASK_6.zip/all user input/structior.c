#include<stdio.h>
#include<conio.h>
main()
{
	getch();
}