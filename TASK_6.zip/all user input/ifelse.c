#include<stdio.h>
#include<conio.h>
main()
{
	int a;
	scanf("%d",&a);
	if(a>10)
	{
		printf("ok");
	}
	else
	{
		printf("wrong");
	}
	getch();
}