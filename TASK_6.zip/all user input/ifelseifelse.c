#include<stdio.h>
#include<conio.h>
main()
{
	int a;
	scanf("%d",&a);
	if(a>10)
	{
		printf("ok");
	}
	else if(a<10)
	{
		printf("wrong");
	}
	else
	{
		printf("error");
	}
	getch();
}