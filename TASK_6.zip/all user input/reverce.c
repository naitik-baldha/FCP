#include <stdio.h>
#include <conio.h>main() 
main()
{
    int i,j,n,m;
    scanf("%d",&n);
    if(n>1)
    {
    for (i=n;i>=1;i--) 
	{
        for (j=1;j<=i;j++)
		{
            printf("*"); 
        }
        printf("\n"); 
    }
    }
    else
    {
        printf("error");
    }
    getch();
}
